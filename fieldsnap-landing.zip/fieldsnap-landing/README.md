# FieldSnap Landing Page

Маркетинговый сайт для FieldSnap. Отдельный проект, разворачивается на поддомене `fieldsnap.app`, пока основное приложение живёт на `app.fieldsnap.app`.

---

## Структура файлов

```
fieldsnap-landing/
└── index.html        ← весь лендинг (один файл, нет зависимостей)
```

Лендинг — **чистый HTML/CSS/JS, без фреймворков и npm**. Деплоится как статика за 30 секунд.

---

## Как встроено относительно приложения

```
fieldsnap.app          ← этот файл (лендинг)
app.fieldsnap.app      ← ваше React/Vite PWA-приложение (FieldSnap-main/)
```

### Почему subdomain split, а не `/app`

Ваше приложение построено как SPA с `BrowserRouter` и маршрутами:
- `/login`
- `/tech/*`
- `/dispatch/*`
- `/admin/*`
- `/superadmin/*`

Если попытаться разместить лендинг в корне того же деплоя (например, Vercel-проекта), возникнут конфликты маршрутизации. Subdomain split — чистое решение: два независимых деплоя без каких-либо компромиссов.

---

## Деплой на Vercel (рекомендуемый вариант)

### 1. Лендинг (fieldsnap.app)

```bash
# Создайте новый Vercel-проект для лендинга
vercel deploy --prod

# В настройках Vercel → Domains → добавьте fieldsnap.app
```

Либо просто перетащите папку `fieldsnap-landing/` в интерфейс Vercel.

### 2. Приложение (app.fieldsnap.app)

Ваш текущий `FieldSnap-main/` деплоится как обычно (уже на `field-snap.vercel.app`). Добавьте кастомный домен `app.fieldsnap.app` в настройках этого Vercel-проекта.

### DNS-записи

```
fieldsnap.app        CNAME  cname.vercel-dns.com
app.fieldsnap.app    CNAME  cname.vercel-dns.com
```

---

## Деплой на Nginx (self-hosted)

```nginx
# fieldsnap.app — лендинг
server {
    server_name fieldsnap.app;
    root /var/www/fieldsnap-landing;
    index index.html;
    try_files $uri $uri/ /index.html;
}

# app.fieldsnap.app — приложение
server {
    server_name app.fieldsnap.app;
    root /var/www/fieldsnap-app/dist;
    index index.html;
    try_files $uri $uri/ /index.html;
}
```

---

## Кнопки на лендинге

| Кнопка | Куда ведёт |
|--------|-----------|
| «Войти» (nav) | `https://app.fieldsnap.app/login` |
| «Запросить демо» | Открывает модальную форму |
| «Обсудить пилот» | Открывает модальную форму |

### Подключение формы к реальному бэкенду

Сейчас форма показывает заглушку (success-экран). Чтобы подключить к Supabase:

```javascript
// В функции submitForm() замените alert на fetch:
async function submitForm() {
  const name = document.getElementById('form-name').value.trim();
  const company = document.getElementById('form-company').value.trim();
  const phone = document.getElementById('form-phone').value.trim();
  const size = document.getElementById('form-size').value;

  if (!name || !phone) {
    alert('Пожалуйста, заполните имя и телефон.');
    return;
  }

  // Вариант 1: Supabase Edge Function
  await fetch('https://YOUR_PROJECT.supabase.co/functions/v1/lead-capture', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, company, phone, size })
  });

  // Вариант 2: Простой fetch на ваш бэкенд
  // await fetch('https://api.fieldsnap.app/leads', { ... });

  // Показываем success
  document.getElementById('modal-form-view').style.display = 'none';
  document.getElementById('modal-success-view').style.display = 'block';
}
```

---

## UTM-параметры и персонализация hero

Лендинг поддерживает отраслевую персонализацию через URL-параметр `?industry=`:

Добавьте этот скрипт после тега `<body>` (или в конец `<script>`):

```javascript
// Динамическая персонализация hero по industry-параметру
(function() {
  const params = new URLSearchParams(window.location.search);
  const industry = params.get('industry');

  const variants = {
    hvac: {
      h1: 'Контроль выездов\nкондиционеров\nв сезон —\nбез хаоса',
      sub: 'FieldSnap помогает HVAC-компаниям держать выезды под контролем в пиковый летний сезон.'
    },
    electric: {
      h1: 'Порядок\nв выездной\nэлектрике —\nот заявки до акта',
      sub: 'FieldSnap помогает электромонтажным компаниям вести чеклисты, фото и подписи по каждому выезду.'
    },
    plumbing: {
      h1: 'Срочные выезды\nпод контролем —\nдаже без\nинтернета',
      sub: 'FieldSnap помогает сантехническим компаниям назначать выезды и фиксировать результат без потерь.'
    }
  };

  if (industry && variants[industry]) {
    const v = variants[industry];
    const h1 = document.querySelector('.hero__h1');
    const sub = document.querySelector('.hero__sub');
    if (h1) h1.innerHTML = v.h1.split('\n').map((l,i) => i===3 ? `<span class="accent">${l}</span>` : l).join('<br>');
    if (sub) sub.textContent = v.sub;
  }
})();
```

**Пример ссылки для холодного письма HVAC-компании:**
```
https://fieldsnap.app?industry=hvac&utm_source=cold_email&utm_campaign=hvac_summer_2026
```

---

## Дизайн-токены

Лендинг использует те же токены, что и приложение (`src/design-system/tokens.ts`):

```css
--bg:     #07090F   /* Основной фон */
--card:   #111827   /* Карточки */
--acc:    #FF5F1F   /* Оранжевый акцент */
--gr:     #0FD47F   /* Зелёный (success) */
--am:     #F5A623   /* Янтарный (warning) */
--bl:     #3D8EFF   /* Синий (info) */
--re:     #FF3B3B   /* Красный (danger) */
```

Шрифты: **Barlow Condensed** (заголовки) + **Barlow** (текст) + **DM Mono** (метки) — те же, что и в приложении.

---

## Чеклист перед запуском

- [ ] Заменить заглушку формы на реальный endpoint (Supabase / email)
- [ ] Поменять `mailto:hello@fieldsnap.app` на рабочую почту
- [ ] Добавить реальный `fieldsnap.app` домен в DNS
- [ ] Добавить `app.fieldsnap.app` к Vercel-проекту приложения
- [ ] Добавить UTM-скрипт для отраслевой персонализации (опционально)
- [ ] Настроить Google Analytics / Yandex.Metrica (опционально)
- [ ] Добавить реальные скриншоты приложения в секцию Screenshots (опционально)
